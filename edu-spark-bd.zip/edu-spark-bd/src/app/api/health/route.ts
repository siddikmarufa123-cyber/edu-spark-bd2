import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// ডাটাবেস সচল কি না দেখার জন্য সহজ endpoint।
export async function GET() {
  const sb = await createClient();
  const { error } = await sb.from("site_published").select("key").limit(1);
  return NextResponse.json({ ok: !error }, { status: error ? 500 : 200 });
}
